<template>
  <div class="search">
    <headers></headers>
  </div>
</template>


<script type="text/javascript">
import headers from './searchs/SearchsHeader'
  export default {
        components:{
            headers  
        }
  }
</script>
<style scoped lang="scss">

</style>


