<template>
  <div class="message">
    <h2>消息</h2>
  </div>
</template>

<style type="text/css"></style>

<script type="text/javascript">
  export default {

  }
</script>

