<template>
  <div class="meet">
    <h2>邂逅</h2>
  </div>
</template>

<style type="text/css"></style>

<script type="text/javascript">
  export default {

  }
</script>

