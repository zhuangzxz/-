<template>
  <div class="myinfo">
    <h2>个人信息</h2>
  </div>
</template>

<style type="text/css"></style>

<script type="text/javascript">
  export default {

  }
</script>

